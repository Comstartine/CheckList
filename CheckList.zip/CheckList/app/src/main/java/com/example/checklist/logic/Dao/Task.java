package com.example.checklist.logic.Dao;

public class Task {
}
